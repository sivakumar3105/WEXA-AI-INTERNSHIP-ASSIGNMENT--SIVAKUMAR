export default function Home() {
  return (
    <div style={{textAlign: "center", marginTop: "50px"}}>
      <h1>Next.js App Deployed on Kubernetes 🚀</h1>
      <p>Assignment submitted by Siva Kumar</p>
    </div>
  )
}
